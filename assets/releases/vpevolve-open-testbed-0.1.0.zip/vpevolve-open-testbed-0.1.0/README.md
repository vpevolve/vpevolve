# VPEvolve open lithography testbed

A differentiable high-NA TCC/SOCS lithography simulator and 20 FreePDK45-derived
layout windows. The public package supports optical and resist simulation of a
mask. It does not include OPC recipe editing or commercial-tool evaluation.

## Contents

- `src/diff_litho/`: simulator, optical-mode construction, and command-line inference.
- `configs/analytic_193nm.json`: the included analytic 193 nm configuration.
- `modes/`: prebuilt analytic modes for -30, 0, and +30 nm focus.
- `layouts/`: 10 Poly and 10 Metal1 GDS windows, a coordinate manifest, and file hashes.
- `tools/gds_to_mask.py`: rasterize a selected GDS window for the simulator.
- `examples/`: inference and differentiable mask-optimization examples.
- `tests/`: simulator and layout-rasterization checks.

## Install

Python 3.10 or newer is required. Install a PyTorch build appropriate for your
machine, then run:

```bash
python -m pip install -e .
```

For test dependencies:

```bash
python -m pip install pytest
python -m pytest -q
```

## Try a released GDS window

The manifest records each window's Poly or Metal1 layer and its 10 x 10 µm
scoring core. This example rasterizes a 1 x 1 µm area within Poly19 at 5 nm
pixels, then runs the simulator:

```bash
python tools/gds_to_mask.py poly-19-dense-x240-y480 mask.png \
  --bbox-um 10 6 11 7 --pixel-nm 5

diff-litho-infer mask.png outputs/poly19 \
  --config configs/analytic_193nm.json --modes modes \
  --input-pixel-nm 5 --device cpu
```

Omit `--bbox-um` to rasterize the window's 14 x 14 µm context box. For a full
window, use `--tiled --core-px 512` and a machine with sufficient memory. The
output contains `aerial.npy`, `resist.npy`, and `resist.png`.

## Differentiable API

```python
from pathlib import Path
import torch
from diff_litho import OpticalConfig, DifferentiableLithographySimulator

config = OpticalConfig.from_json("configs/analytic_193nm.json")
modes = {
    focus: Path("modes") / f"self_tcc_focus_{focus:+g}nm.npz"
    for focus in config.focus_nm
}
model = DifferentiableLithographySimulator(config, modes).to("cpu")
mask = torch.rand(512, 512, requires_grad=True)
result = model(mask)
result["probability"].mean().backward()
print(mask.grad.shape)
```

The differentiable outputs are `aerial`, `exposed_aerial`, `logits`, and
`probability`. `resist` is a hard-threshold reporting output. `simulate_tiled()`
retains the autograd graph for larger inputs.

## Optical configuration

The included preset uses 193 nm wavelength, NA 1.35, annular illumination
(sigma 0.6-0.9), an unpolarized vector pupil, 5 nm native optical pixels,
60 SOCS modes, and focus values of -30, 0, and +30 nm. The prebuilt modes can
be regenerated from the analytic configuration:

```bash
diff-litho-build-modes --config configs/analytic_193nm.json \
  --output modes --device cpu
```

The Apache License, Version 2.0 is in `LICENSE`; layout provenance and checksums are in
`layouts/manifest.json`.
