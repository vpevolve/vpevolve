# SPDX-License-Identifier: Apache-2.0
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from diff_litho import OpticalConfig, DifferentiableLithographySimulator


ROOT = Path(__file__).resolve().parents[1]
device = "cuda" if torch.cuda.is_available() else "cpu"
config = OpticalConfig.from_json(
    ROOT / "configs" / "analytic_193nm.json")
modes = {
    focus: ROOT / "modes" / f"self_tcc_focus_{focus:+g}nm.npz"
    for focus in config.focus_nm}
simulator = DifferentiableLithographySimulator(
    config, modes).to(device)

side = 512
y, x = np.mgrid[:side, :side]
mask = (
    (np.abs(x - side // 2) < 50) |
    (np.abs(y - side // 2) < 50)
).astype(np.float32)

with torch.no_grad():
    result = simulator(mask, dose=1.0, focus_nm=0.0)

output = ROOT / "outputs" / "inference_example"
output.mkdir(parents=True, exist_ok=True)
np.save(output / "aerial.npy", result["aerial"].cpu().numpy())
Image.fromarray(
    result["resist"].cpu().numpy().astype(np.uint8) * 255
).save(output / "resist.png")
print(output)
