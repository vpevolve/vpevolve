# SPDX-License-Identifier: Apache-2.0
"""Minimal differentiable OPC example using a continuous mask variable."""

from pathlib import Path

import torch
import torch.nn.functional as F

from diff_litho import OpticalConfig, DifferentiableLithographySimulator


ROOT = Path(__file__).resolve().parents[1]
device = "cuda" if torch.cuda.is_available() else "cpu"
config = OpticalConfig.from_json(
    ROOT / "configs" / "analytic_193nm.json")
modes = {
    focus: ROOT / "modes" / f"self_tcc_focus_{focus:+g}nm.npz"
    for focus in config.focus_nm}
simulator = DifferentiableLithographySimulator(
    config, modes).to(device)

side = 256
y, x = torch.meshgrid(
    torch.arange(side, device=device),
    torch.arange(side, device=device), indexing="ij")
target = (
    (torch.abs(x - side // 2) < 35) |
    (torch.abs(y - side // 2) < 35)
).to(torch.float32)

# Optimize logits so the physical mask always stays in [0,1].
mask_parameter = torch.nn.Parameter(
    torch.where(target > 0, 2.0, -2.0))
optimizer = torch.optim.Adam([mask_parameter], lr=.08)

for step in range(20):
    optimizer.zero_grad()
    soft_mask = torch.sigmoid(mask_parameter)
    result = simulator(soft_mask, dose=1.0, focus_nm=0.0)
    image_loss = F.binary_cross_entropy_with_logits(
        result["logits"], target)
    binary_penalty = torch.mean(soft_mask * (1.0 - soft_mask))
    loss = image_loss + .01 * binary_penalty
    loss.backward()
    optimizer.step()
    print(
        f"step={step:02d} loss={loss.item():.6f} "
        f"gradient_norm={mask_parameter.grad.norm().item():.6f}")
