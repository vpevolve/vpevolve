# SPDX-License-Identifier: Apache-2.0
"""Verify the released GDS corpus and its simulator input path."""
import hashlib
import json
from pathlib import Path
import sys

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from gds_to_mask import rasterize, read_polygons  # noqa: E402


def test_layout_manifest_and_hashes():
    manifest = json.loads((ROOT / "layouts/manifest.json").read_text())
    rows = manifest["layouts"]
    assert len(rows) == 20
    assert sum(row["layer"] == "Poly" for row in rows) == 10
    assert sum(row["layer"] == "Metal1" for row in rows) == 10
    for row in rows:
        path = ROOT / "layouts" / row["file"]
        assert path.name == row["file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"]
        dbu_um, polygons = read_polygons(path, row["gds_layer"], row["datatype"])
        assert abs(dbu_um - row["dbu_um"]) < 1e-12
        assert polygons


def test_gds_mask_rasterization(tmp_path):
    row = next(row for row in json.loads(
        (ROOT / "layouts/manifest.json").read_text())["layouts"]
        if row["case"].startswith("poly-19-"))
    output = tmp_path / "mask.png"
    width, height, _ = rasterize(
        ROOT / "layouts" / row["file"], output,
        row["gds_layer"], row["datatype"], [10, 6, 11, 7], 5)
    image = Image.open(output)
    assert (width, height) == image.size == (200, 200)
    assert image.getextrema() == (0, 255)
