# SPDX-License-Identifier: Apache-2.0
import numpy as np

from diff_litho.source import uniform_annular_quadrature


def test_annular_quadrature():
    source = uniform_annular_quadrature(.6, .9, 8, 32)
    radius = np.linalg.norm(source[:, :2], axis=1)
    assert source.shape == (256, 3)
    assert radius.min() >= .6
    assert radius.max() <= .9
    assert np.isclose(source[:, 2].sum(), 1.0)
