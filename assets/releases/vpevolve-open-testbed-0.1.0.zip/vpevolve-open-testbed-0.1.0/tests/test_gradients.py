# SPDX-License-Identifier: Apache-2.0
from pathlib import Path

import torch

from diff_litho import OpticalConfig, DifferentiableLithographySimulator


ROOT = Path(__file__).resolve().parents[1]


def simulator():
    config = OpticalConfig.from_json(
        ROOT / "configs" / "analytic_193nm.json")
    modes = {
        focus: ROOT / "modes" / f"self_tcc_focus_{focus:+g}nm.npz"
        for focus in config.focus_nm}
    return DifferentiableLithographySimulator(
        config, modes, input_pixel_nm=5.0)


def test_mask_dose_and_focus_gradients_are_finite():
    model = simulator()
    mask = torch.rand((48, 64), requires_grad=True)
    dose = torch.tensor(1.0, requires_grad=True)
    focus = torch.tensor(3.0, requires_grad=True)
    result = model(mask, dose=dose, focus_nm=focus)
    result["probability"].mean().backward()
    assert mask.grad is not None and torch.isfinite(mask.grad).all()
    assert mask.grad.abs().sum() > 0
    assert dose.grad is not None and torch.isfinite(dose.grad)
    assert focus.grad is not None and torch.isfinite(focus.grad)


def test_dose_is_monotonic():
    model = simulator()
    mask = torch.rand((48, 64))
    low = model(mask, dose=.97)["probability"]
    high = model(mask, dose=1.03)["probability"]
    assert torch.all(high >= low)
