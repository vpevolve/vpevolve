# SPDX-License-Identifier: Apache-2.0
from pathlib import Path

import torch

from diff_litho import OpticalConfig, DifferentiableLithographySimulator


ROOT = Path(__file__).resolve().parents[1]


def test_valid_core_tiling_matches_full_and_keeps_gradient():
    config = OpticalConfig.from_json(
        ROOT / "configs" / "analytic_193nm.json")
    modes = {
        focus: ROOT / "modes" / f"self_tcc_focus_{focus:+g}nm.npz"
        for focus in config.focus_nm}
    model = DifferentiableLithographySimulator(
        config, modes, input_pixel_nm=5.0)
    torch.manual_seed(4)
    mask = torch.rand((30, 35), requires_grad=True)
    full = model(mask, focus_nm=0.0)
    tiled = model.simulate_tiled(
        mask, focus_nm=0.0, core_px=20)
    assert torch.max(torch.abs(
        full["aerial"] - tiled["aerial"])) < 1e-5
    assert torch.equal(full["resist"], tiled["resist"])
    tiled["probability"].mean().backward()
    assert mask.grad is not None and torch.isfinite(mask.grad).all()
