# Release notice

Copyright 2026 VPEvolve contributors.

This release contains an independently implemented, differentiable optical and
resist simulator; analytic optical modes generated from the included
configuration; and 20 layout windows derived from FreePDK45-generated
full-chip designs.

FreePDK45 is a project of NC State EDA and is distributed under Apache-2.0:
https://eda.ncsu.edu/freepdk/freepdk45/

The simulator and layout windows are released under the Apache License, Version 2.0 in
`LICENSE`. The package contains no commercial optical model binaries, process
manuals, OPC recipes, or commercial-tool executables.
