# SPDX-License-Identifier: Apache-2.0
"""Rasterize one released flat GDSII window to an 8-bit mask PNG."""
from __future__ import annotations

import argparse
import json
import math
import struct
from pathlib import Path

from PIL import Image, ImageDraw


def _real8(data: bytes) -> float:
    if len(data) != 8:
        raise ValueError("Invalid GDSII real8 value")
    sign = -1 if data[0] & 0x80 else 1
    return sign * (int.from_bytes(data[1:], "big") / 2**56) * 16 ** ((data[0] & 0x7F) - 64)


def read_polygons(path: Path, layer: int, datatype: int):
    data = path.read_bytes()
    offset = 0
    dbu_um = None
    current = None
    polygons = []
    while offset < len(data):
        if offset + 4 > len(data):
            raise ValueError("Truncated GDSII record")
        length, record, _kind = struct.unpack(">HBB", data[offset:offset + 4])
        if length < 4 or offset + length > len(data):
            raise ValueError("Invalid GDSII record length")
        value = data[offset + 4:offset + length]
        offset += length
        if record == 3:  # UNITS
            dbu_um = _real8(value[:8])
        elif record == 8:  # BOUNDARY
            current = {}
        elif record in (9, 10, 11, 12):  # PATH, SREF, AREF, TEXT
            raise ValueError("The released converter accepts flat boundary polygons only")
        elif current is not None and record == 13:  # LAYER
            current["layer"] = struct.unpack(">h", value)[0]
        elif current is not None and record == 14:  # DATATYPE
            current["datatype"] = struct.unpack(">h", value)[0]
        elif current is not None and record == 16:  # XY
            if len(value) % 8:
                raise ValueError("Invalid GDSII XY record")
            numbers = struct.unpack(">" + "i" * (len(value) // 4), value)
            current["points"] = list(zip(numbers[::2], numbers[1::2]))
        elif current is not None and record == 17:  # ENDEL
            if current.get("layer") == layer and current.get("datatype") == datatype:
                if len(current.get("points", [])) < 4:
                    raise ValueError("Invalid boundary polygon")
                polygons.append(current["points"])
            current = None
    if dbu_um is None or not polygons:
        raise ValueError("GDSII units or selected layer missing")
    return dbu_um, polygons


def rasterize(path: Path, output: Path, layer: int, datatype: int,
              bbox_um: list[float], pixel_nm: float) -> tuple[int, int, int]:
    if pixel_nm <= 0 or not math.isclose(5 / pixel_nm, round(5 / pixel_nm), abs_tol=1e-9):
        raise ValueError("Pixel size must divide the simulator's 5 nm native pixel")
    x0, y0, x1, y1 = bbox_um
    if not x0 < x1 or not y0 < y1:
        raise ValueError("Invalid bounding box")
    width = round((x1 - x0) * 1000 / pixel_nm)
    height = round((y1 - y0) * 1000 / pixel_nm)
    if width * height > 50_000_000:
        raise ValueError("Raster exceeds 50 million pixels; use a smaller crop or coarser pixel")
    dbu_um, polygons = read_polygons(path, layer, datatype)
    image = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(image)
    for polygon in polygons:
        points = [((x * dbu_um - x0) * 1000 / pixel_nm - 0.5,
                   (y1 - y * dbu_um) * 1000 / pixel_nm - 0.5)
                  for x, y in polygon]
        draw.polygon(points, fill=255)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)
    return width, height, len(polygons)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", help="Case identifier from layouts/manifest.json")
    parser.add_argument("output", type=Path, help="Output 8-bit PNG mask")
    parser.add_argument("--manifest", type=Path,
                        default=Path(__file__).resolve().parents[1] / "layouts/manifest.json")
    parser.add_argument("--bbox-um", type=float, nargs=4,
                        help="Override context crop: x0 y0 x1 y1 in micrometers")
    parser.add_argument("--pixel-nm", type=float, default=5.0)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    case = next((row for row in manifest["layouts"] if row["case"] == args.case), None)
    if case is None:
        parser.error(f"Unknown case: {args.case}")
    path = args.manifest.parent / case["file"]
    width, height, polygons = rasterize(
        path, args.output, case["gds_layer"], case["datatype"],
        args.bbox_um or case["context_bbox_um"], args.pixel_nm)
    print(f"{args.case}: {width}x{height} pixels, {polygons} polygons, {args.pixel_nm:g} nm/pixel")


if __name__ == "__main__":
    main()
