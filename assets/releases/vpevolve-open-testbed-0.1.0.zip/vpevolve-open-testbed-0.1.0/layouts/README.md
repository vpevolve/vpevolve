# FreePDK45-derived layout windows

This directory contains 20 GDSII windows cropped from FreePDK45-generated
full-chip layouts: 10 Poly (GDS layer 9/0) and 10 Metal1 (11/0), with two
windows per layer in each density group from very sparse to very dense.

Each window has a 10 x 10 µm scoring core and 2 µm of surrounding context.
`manifest.json` records the exact core and context coordinates in micrometers,
GDS database units, layer, density group, byte size, and SHA-256 digest. The GDS
files retain their original layout coordinates and contain flat boundary
polygons for their target layer.

The filenames preserve the case identifiers used in the evaluation. They do
not contain names, machine paths, repository identifiers, or process manuals.
