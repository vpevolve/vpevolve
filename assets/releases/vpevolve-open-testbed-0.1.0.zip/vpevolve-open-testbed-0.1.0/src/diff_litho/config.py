# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class OpticalConfig:
    wavelength_um: float = 0.193
    na: float = 1.35
    ambient_n: float = 1.44
    sigma_inner: float = 0.6
    sigma_outer: float = 0.9
    radial_samples: int = 8
    angular_samples: int = 32
    physical_window_um: float = 2.56
    native_pixel_nm: float = 5.0
    vector_mode: str = "unpolarized"
    obliquity: str = "inverse_sqrt_cos"
    rank: int = 60
    open_field_intensity: float = 0.7943214774
    background_intensity: float = 0.06
    background_phase_deg: float = 180.0
    resist_threshold: float = 0.0873
    resist_gain: float = 100.0
    focus_nm: tuple[float, ...] = (-30.0, 0.0, 30.0)

    @classmethod
    def from_json(cls, path: str | Path) -> "OpticalConfig":
        values = json.loads(Path(path).read_text(encoding="utf-8"))
        values["focus_nm"] = tuple(float(x) for x in values["focus_nm"])
        return cls(**values)

    def to_dict(self):
        value = asdict(self)
        value["focus_nm"] = list(self.focus_nm)
        return value
