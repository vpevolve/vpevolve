# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

from .config import OpticalConfig
from .source import uniform_annular_quadrature


@dataclass(frozen=True)
class ModeSet:
    modes: np.ndarray
    eigenvalues: np.ndarray
    metadata: dict


def _randomized_svd(matrix, rank, oversample, power_iterations, seed):
    m, n = matrix.shape
    width = min(rank + oversample, m, n)
    generator = torch.Generator(device=matrix.device)
    generator.manual_seed(seed)
    omega = torch.complex(
        torch.randn((n, width), device=matrix.device, generator=generator),
        torch.randn((n, width), device=matrix.device, generator=generator),
    ).to(matrix.dtype) / math.sqrt(2.0)
    sample = matrix @ omega
    for _ in range(power_iterations):
        sample = matrix @ (matrix.mH @ sample)
    basis, _ = torch.linalg.qr(sample, mode="reduced")
    _, singular, vh = torch.linalg.svd(
        basis.mH @ matrix, full_matrices=False)
    return vh[:rank], singular[:rank].square()


def build_mode_set(
    config: OpticalConfig,
    focus_nm: float,
    *,
    device: str | torch.device = "cpu",
    oversample: int = 12,
    power_iterations: int = 2,
    seed: int = 42,
) -> ModeSet:
    """Construct vector TCC modes without proprietary model data."""
    device = torch.device(device)
    source_np = uniform_annular_quadrature(
        config.sigma_inner, config.sigma_outer,
        config.radial_samples, config.angular_samples)
    source = torch.as_tensor(source_np, dtype=torch.float32, device=device)
    cutoff = config.na / config.wavelength_um
    union_cutoff = cutoff * (1.0 + config.sigma_outer)
    df = 1.0 / config.physical_window_um
    half = int(math.ceil(union_cutoff / df))
    coord = torch.arange(
        -half, half + 1, dtype=torch.float32, device=device) * df
    fy, fx = torch.meshgrid(coord, coord, indexing="ij")
    rows = []
    for point in source:
        qx, qy = fx + point[0] * cutoff, fy + point[1] * cutoff
        rho2 = qx.square() + qy.square()
        support = rho2 <= cutoff ** 2
        ux = config.wavelength_um / config.ambient_n * qx
        uy = config.wavelength_um / config.ambient_n * qy
        uz = torch.sqrt(torch.clamp(
            1.0 - ux.square() - uy.square(), min=1e-7))
        if config.obliquity == "inverse_sqrt_cos":
            apo = torch.rsqrt(uz)
        elif config.obliquity == "sqrt_cos":
            apo = torch.sqrt(uz)
        elif config.obliquity == "none":
            apo = torch.ones_like(uz)
        else:
            raise ValueError(f"unknown obliquity: {config.obliquity}")
        defocus_um = -float(focus_nm) * 1e-3
        axial = torch.sqrt(torch.clamp(
            config.ambient_n ** 2 -
            config.wavelength_um ** 2 * rho2, min=0.0))
        phase = torch.exp((1j * (
            2.0 * math.pi * defocus_um / config.wavelength_um *
            (axial - config.ambient_n))).to(torch.complex64))
        common = support.to(torch.complex64) * phase
        source_scale = torch.sqrt(point[2])
        if config.vector_mode == "scalar":
            components = ((apo, 1.0),)
        elif config.vector_mode == "unpolarized":
            uxuy = ux * uy
            components = (
                (apo * (1.0 - ux.square()), .5),
                (apo * (-uxuy), .5),
                (apo * (-ux * uz), .5),
                (apo * (-uxuy), .5),
                (apo * (1.0 - uy.square()), .5),
                (apo * (-uy * uz), .5),
            )
        else:
            raise ValueError(f"unknown vector mode: {config.vector_mode}")
        for component, polarization_weight in components:
            rows.append((
                source_scale * math.sqrt(polarization_weight) *
                component * common).reshape(-1))
    systems = torch.stack(rows)
    modes, eigenvalues = _randomized_svd(
        systems, config.rank, oversample, power_iterations, seed)
    modes = modes.reshape(-1, len(coord), len(coord))
    retained = float(
        eigenvalues.sum() / torch.sum(torch.abs(systems).square()))
    center = len(coord) // 2
    dc = torch.sum(
        eigenvalues * torch.abs(modes[:, center, center]).square())
    eigenvalues = eigenvalues * (config.open_field_intensity / dc)
    metadata = {
        "generator": "independent analytic high-NA TCC/SOCS",
        "focus_nm": float(focus_nm),
        "source_points": len(source_np),
        "coherent_channels": len(rows),
        "rank": len(eigenvalues),
        "frequency_side": len(coord),
        "frequency_step_per_um": df,
        "physical_window_um": config.physical_window_um,
        "retained_unscaled_energy_fraction": retained,
        "open_field_intensity": config.open_field_intensity,
        "config": config.to_dict(),
    }
    return ModeSet(
        modes.detach().cpu().numpy().astype(np.complex64),
        eigenvalues.detach().cpu().numpy().astype(np.float32),
        metadata)


def save_mode_set(path: str | Path, mode_set: ModeSet):
    np.savez_compressed(
        path,
        modes=mode_set.modes,
        eigenvalues=mode_set.eigenvalues,
        metadata_json=np.asarray(json.dumps(mode_set.metadata)))


def load_mode_set(path: str | Path) -> ModeSet:
    with np.load(path, allow_pickle=False) as data:
        return ModeSet(
            data["modes"].astype(np.complex64),
            data["eigenvalues"].astype(np.float32),
            json.loads(str(data["metadata_json"])))
