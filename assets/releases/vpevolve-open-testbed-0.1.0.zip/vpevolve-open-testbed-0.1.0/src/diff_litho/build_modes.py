# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
from pathlib import Path

import torch

from .config import OpticalConfig
from .tcc import build_mode_set, save_mode_set


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default=(
        "cuda" if torch.cuda.is_available() else "cpu"))
    args = parser.parse_args()
    config = OpticalConfig.from_json(args.config)
    args.output.mkdir(parents=True, exist_ok=True)
    for focus in config.focus_nm:
        modes = build_mode_set(config, focus, device=args.device)
        path = args.output / f"self_tcc_focus_{focus:+g}nm.npz"
        save_mode_set(path, modes)
        print(path)


if __name__ == "__main__":
    main()
