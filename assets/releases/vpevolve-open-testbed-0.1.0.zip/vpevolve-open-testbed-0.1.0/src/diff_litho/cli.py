# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from .config import OpticalConfig
from .simulator import DifferentiableLithographySimulator


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mask", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--modes", type=Path, required=True)
    parser.add_argument("--device", default=(
        "cuda" if torch.cuda.is_available() else "cpu"))
    parser.add_argument("--dose", type=float, default=1.0)
    parser.add_argument("--focus-nm", type=float, default=0.0)
    parser.add_argument("--input-pixel-nm", type=float, default=1.0)
    parser.add_argument("--tiled", action="store_true")
    parser.add_argument("--core-px", type=int, default=512)
    args = parser.parse_args()
    config = OpticalConfig.from_json(args.config)
    mode_paths = {
        focus: args.modes / f"self_tcc_focus_{focus:+g}nm.npz"
        for focus in config.focus_nm}
    simulator = DifferentiableLithographySimulator(
        config, mode_paths, input_pixel_nm=args.input_pixel_nm).to(args.device)
    mask = np.asarray(Image.open(args.mask).convert("L"), dtype=np.float32) / 255
    with torch.no_grad():
        if args.tiled:
            result = simulator.simulate_tiled(
                mask, dose=args.dose, focus_nm=args.focus_nm,
                core_px=args.core_px)
        else:
            result = simulator(mask, dose=args.dose, focus_nm=args.focus_nm)
    args.output.mkdir(parents=True, exist_ok=True)
    np.save(args.output / "aerial.npy", result["aerial"].cpu().numpy())
    np.save(
        args.output / "resist.npy",
        result["resist"].cpu().numpy().astype(np.uint8))
    Image.fromarray(
        result["resist"].cpu().numpy().astype(np.uint8) * 255
    ).save(args.output / "resist.png")


if __name__ == "__main__":
    main()
