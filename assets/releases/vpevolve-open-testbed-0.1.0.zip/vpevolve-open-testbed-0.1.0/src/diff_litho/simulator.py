# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import math
from pathlib import Path

import torch
import torch.nn.functional as F

from .config import OpticalConfig
from .tcc import ModeSet, load_mode_set


class DifferentiableLithographySimulator(torch.nn.Module):
    """Differentiable mask-to-resist simulator with fixed physical modes."""

    def __init__(
        self,
        config: OpticalConfig,
        modes_by_focus: dict[float, ModeSet | str | Path],
        *,
        input_pixel_nm: float = 1.0,
        halo_nm: float | None = None,
        mode_batch: int = 10,
    ):
        super().__init__()
        self.config = config
        self.input_pixel_nm = float(input_pixel_nm)
        ratio = config.native_pixel_nm / self.input_pixel_nm
        if abs(ratio - round(ratio)) > 1e-8:
            raise ValueError("native/input pixel ratio must be an integer")
        self.downsample = int(round(ratio))
        self.halo_px = int(round(
            (halo_nm if halo_nm is not None
             else config.physical_window_um * 500.0) /
            self.input_pixel_nm))
        if self.halo_px % self.downsample:
            raise ValueError("halo must align to native grid")
        self.mode_batch = int(mode_batch)
        self._focus_names = {}
        for focus, value in modes_by_focus.items():
            current = load_mode_set(value) if isinstance(
                value, (str, Path)) else value
            key = str(float(focus)).replace("-", "m").replace(".", "p")
            self.register_buffer(
                f"modes_{key}", torch.as_tensor(current.modes))
            self.register_buffer(
                f"eigenvalues_{key}", torch.as_tensor(current.eigenvalues))
            self._focus_names[float(focus)] = key
        self._transfer_cache = {}

    def _mode_tensors(self, focus: float):
        if focus not in self._focus_names:
            raise ValueError(
                f"focus {focus} unavailable; have {sorted(self._focus_names)}")
        key = self._focus_names[focus]
        return getattr(self, f"modes_{key}"), getattr(
            self, f"eigenvalues_{key}")

    def _transfers(self, modes, height, width):
        key = (
            int(modes.data_ptr()), height, width, modes.device, modes.dtype)
        cached = self._transfer_cache.get(key)
        if cached is not None:
            return cached
        native_side = int(round(
            self.config.physical_window_um /
            (self.config.native_pixel_nm * 1e-3)))
        source_side = modes.shape[-1]
        if min(height, width) < native_side:
            raise ValueError("input plus halo is smaller than optical window")
        source0 = native_side // 2 - source_side // 2
        destination_y = height // 2 - native_side // 2
        destination_x = width // 2 - native_side // 2
        built = []
        for start in range(0, len(modes), self.mode_batch):
            current = modes[start:start + self.mode_batch]
            frequency = torch.zeros(
                (len(current), native_side, native_side),
                dtype=current.dtype, device=current.device)
            frequency[:, source0:source0 + source_side,
                      source0:source0 + source_side] = current
            spatial = torch.fft.fftshift(torch.fft.ifft2(
                torch.fft.ifftshift(frequency, dim=(-2, -1))),
                dim=(-2, -1))
            padded = torch.zeros(
                (len(current), height, width),
                dtype=current.dtype, device=current.device)
            padded[:, destination_y:destination_y + native_side,
                   destination_x:destination_x + native_side] = spatial
            built.append(torch.fft.fft2(
                torch.fft.ifftshift(padded, dim=(-2, -1))))
        result = torch.cat(built)
        self._transfer_cache[key] = result
        return result

    def _aerial_exact_focus(self, transmission, focus):
        modes, eigenvalues = self._mode_tensors(float(focus))
        transfers = self._transfers(
            modes, transmission.shape[-2], transmission.shape[-1])
        mask_fft = torch.fft.fft2(transmission.to(torch.complex64))
        intensity = torch.zeros_like(transmission, dtype=torch.float32)
        for start in range(0, len(modes), self.mode_batch):
            stop = min(len(modes), start + self.mode_batch)
            fields = torch.fft.ifft2(
                transfers[start:stop] * mask_fft[None])
            intensity = intensity + torch.sum(
                eigenvalues[start:stop, None, None] *
                torch.abs(fields).square(), dim=0)
        return intensity

    def _aerial(self, transmission, focus_nm):
        if torch.is_tensor(focus_nm):
            if not all(x in self._focus_names for x in (-30.0, 0.0, 30.0)):
                raise ValueError("continuous focus requires -30/0/+30 modes")
            normalized = focus_nm.to(
                device=transmission.device, dtype=torch.float32) / 30.0
            minus = self._aerial_exact_focus(transmission, -30.0)
            nominal = self._aerial_exact_focus(transmission, 0.0)
            plus = self._aerial_exact_focus(transmission, 30.0)
            return (
                nominal + normalized * .5 * (plus - minus) +
                normalized.square() * .5 * (plus + minus - 2 * nominal))
        return self._aerial_exact_focus(transmission, float(focus_nm))

    def forward(
        self,
        mask_clear,
        *,
        dose=1.0,
        focus_nm=0.0,
        add_halo=True,
    ):
        if not torch.is_tensor(mask_clear):
            mask_clear = torch.as_tensor(mask_clear, dtype=torch.float32)
        mask_clear = mask_clear.to(
            device=next(self.buffers()).device, dtype=torch.float32)
        if mask_clear.ndim != 2:
            raise ValueError("mask_clear must have shape [H,W]")
        height, width = mask_clear.shape
        halo = self.halo_px if add_halo else 0
        physical = F.pad(
            mask_clear, (halo, halo, halo, halo), value=0.0)
        pad_h = (-physical.shape[0]) % self.downsample
        pad_w = (-physical.shape[1]) % self.downsample
        physical = F.pad(physical, (0, pad_w, 0, pad_h), value=0.0)
        native = F.avg_pool2d(
            physical[None, None], self.downsample,
            stride=self.downsample)[0, 0]
        phase = math.radians(self.config.background_phase_deg)
        background = math.sqrt(
            self.config.background_intensity) * complex(
                math.cos(phase), math.sin(phase))
        transmission = (
            torch.as_tensor(
                background, dtype=torch.complex64, device=native.device) +
            (1.0 - background) * native)
        aerial_native = self._aerial(transmission, focus_nm)
        aerial_full = F.interpolate(
            aerial_native[None, None], size=physical.shape,
            mode="bicubic", align_corners=False)[0, 0]
        aerial = aerial_full[
            halo:halo + height, halo:halo + width]
        dose_tensor = torch.as_tensor(
            dose, dtype=torch.float32, device=aerial.device)
        exposed = dose_tensor * aerial
        logits = self.config.resist_gain * (
            exposed - self.config.resist_threshold)
        return {
            "aerial": aerial,
            "exposed_aerial": exposed,
            "logits": logits,
            "probability": torch.sigmoid(logits),
            "resist": logits >= 0,
        }

    def simulate_tiled(
        self, mask_clear, *, dose=1.0, focus_nm=0.0, core_px=1000):
        """Differentiable valid-core tiling; output remains in the graph."""
        if not torch.is_tensor(mask_clear):
            mask_clear = torch.as_tensor(mask_clear, dtype=torch.float32)
        device = next(self.buffers()).device
        mask_clear = mask_clear.to(device=device, dtype=torch.float32)
        if core_px % self.downsample:
            raise ValueError("core_px must align to native grid")
        h, w = mask_clear.shape
        tiled_h = math.ceil(h / core_px) * core_px
        tiled_w = math.ceil(w / core_px) * core_px
        halo = self.halo_px
        padded = F.pad(mask_clear, (
            halo, halo + tiled_w - w, halo, halo + tiled_h - h))
        rows = {key: [] for key in (
            "aerial", "exposed_aerial", "logits",
            "probability", "resist")}
        for y0 in range(0, tiled_h, core_px):
            current = {key: [] for key in rows}
            for x0 in range(0, tiled_w, core_px):
                tile = padded[
                    y0:y0 + core_px + 2 * halo,
                    x0:x0 + core_px + 2 * halo]
                result = self(
                    tile, dose=dose, focus_nm=focus_nm, add_halo=False)
                for key in rows:
                    current[key].append(result[key][
                        halo:halo + core_px, halo:halo + core_px])
            for key in rows:
                rows[key].append(torch.cat(current[key], dim=1))
        return {
            key: torch.cat(value, dim=0)[:h, :w]
            for key, value in rows.items()}
