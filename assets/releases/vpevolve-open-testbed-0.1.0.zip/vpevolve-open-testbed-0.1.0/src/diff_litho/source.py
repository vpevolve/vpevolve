# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import math

import numpy as np


def uniform_annular_quadrature(
    sigma_inner: float,
    sigma_outer: float,
    radial_samples: int,
    angular_samples: int,
) -> np.ndarray:
    """Equal-area midpoint quadrature for a uniform sharp annular source."""
    if not 0 <= sigma_inner < sigma_outer:
        raise ValueError("require 0 <= sigma_inner < sigma_outer")
    if radial_samples <= 0 or angular_samples <= 0:
        raise ValueError("source sample counts must be positive")
    edges2 = np.linspace(
        sigma_inner ** 2, sigma_outer ** 2, radial_samples + 1)
    radius = np.sqrt(.5 * (edges2[:-1] + edges2[1:]))
    angle = (np.arange(angular_samples) + .5) * (
        2.0 * math.pi / angular_samples)
    rr, aa = np.meshgrid(radius, angle, indexing="ij")
    weight = np.full(
        rr.size, 1.0 / rr.size, dtype=np.float64)
    return np.column_stack((
        (rr * np.cos(aa)).ravel(),
        (rr * np.sin(aa)).ravel(),
        weight,
    ))
