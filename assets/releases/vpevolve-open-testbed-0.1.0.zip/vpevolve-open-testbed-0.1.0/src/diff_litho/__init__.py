# SPDX-License-Identifier: Apache-2.0
"""Differentiable high-NA TCC/SOCS lithography simulator."""

from .config import OpticalConfig
from .simulator import DifferentiableLithographySimulator
from .tcc import ModeSet, build_mode_set, load_mode_set, save_mode_set

__all__ = [
    "OpticalConfig",
    "ModeSet",
    "build_mode_set",
    "load_mode_set",
    "save_mode_set",
    "DifferentiableLithographySimulator",
]

__version__ = "0.1.0"
